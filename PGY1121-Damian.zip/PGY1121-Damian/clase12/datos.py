#ejemplo de uso de repositorio
print("datos personales")
print(" ")
vnom = input("Ingrese su nombre: ")
while True:
 try:
    vedad =int(input("Ingrese su edad: "))
    break
 except:
    print(" Valo  no corresponde") 


print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
print(f"su Nombre es : {vnom} ")
print(f"Su edad es : {vedad}")

print ("Programa finalizado.....")